#!/bin/sh

groups $FT_USER | tr " " ","
