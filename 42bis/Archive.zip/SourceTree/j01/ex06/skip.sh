ls -l | sed "n;d" | tr -d '\n'
