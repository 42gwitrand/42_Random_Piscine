/*
** my_isneg.c for my_isneg in /home/vautri_b/test/J03
** 
** Made by bertrand vautrin
** Login   <vautri_b@epitech.net>
** 
** Started on  Wed Sep 30 10:35:16 2015 bertrand vautrin
** Last update Thu Oct  1 18:10:38 2015 bertrand vautrin
*/

int	my_isneg(int n)
{
  if (n >= 0)
    {
      my_putchar('P');
    }
  else
    {
      my_putchar('N');
    }
}
