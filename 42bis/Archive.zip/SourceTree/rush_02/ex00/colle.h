/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gwitrand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/17 18:58:18 by gwitrand          #+#    #+#             */
/*   Updated: 2016/09/17 18:58:19 by gwitrand         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef __COLLE_H
# define __COLLE_H

char		*colle0(int x, int y);
char		*colle1(int x, int y);
char		*colle2(int x, int y);
char		*colle3(int x, int y);
char		*colle4(int x, int y);

#endif
