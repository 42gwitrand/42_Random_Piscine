echo "Bravo ! tu viens de demander une TIG :D"
echo "Tu commence lundi matin a 10h !"
echo "BRAVO !"
