#/bin/sh

ldapsearch -LLL -Q uid=$1
